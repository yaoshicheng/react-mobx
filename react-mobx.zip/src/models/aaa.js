export default {

  namespace: 'aaa',

  state: {
    name:'这是aaa的model',
    testData:"2432423"
  },

  subscriptions: {

  },

  effects: {
    *aaa({ payload = {} }, { call, put }){
      console.log(111)
      yield put({
        type: 'saveAAA',
        payload: {test:222},
      });
    }
  },

  reducers: {
    saveAAA(state, { payload }) {
      return {
        ...state,
        testData: payload.test,
      };
    },
  },

};
