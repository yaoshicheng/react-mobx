import { observable,action,computed,autorun,flow } from "mobx";

var store = observable({
  /* 一些观察的状态 */
  title: "",
  absoluteVar:"asfasfs",

  get getLength(){
    return this.title.length;
  },

  /* action  */
  setTitle:function(title){
    store.title = title
  },
  // flow示例代码
  // fetchProjects : flow(function * () { // <- 注意*号，这是生成器函数！
  //   this.githubProjects = []
  //   this.state = "pending"
  //   try {
  //     const projects = yield fetchGithubProjectsSomehow() // 用 yield 代替 await
  //     const filteredProjects = somePreprocessing(projects)
  //     // 异步代码块会被自动包装成动作并修改状态
  //     this.state = "done"
  //     this.githubProjects = filteredProjects
  //   } catch (error) {
  //     this.state = "error"
  //   }
  // })
},{
  absoluteVar:observable.ref,
  setTitle:action,
  getLength:computed,
});

autorun(() => console.log(store.title));

export default store