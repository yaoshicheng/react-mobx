import { observable,action ,decorate,computed} from "mobx";
class MM3 {
  @observable name = "";
  @action setTitle=(name)=>{
    this.name = name
  };
  @computed get getLength(){
    return this.name.length
  };
  constructor(name){
    this.name = name;
  }
}

export default MM3