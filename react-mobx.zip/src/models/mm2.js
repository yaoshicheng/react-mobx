import { observable,action ,decorate,computed} from "mobx";
class MM2 {
  name = "";
  setTitle=(name)=>{
    this.name = name
  };
  get getLength(){
    return this.name.length
  };
  constructor(name){
    this.name = name;
  }
}
decorate(MM2, {
  name: observable,
  setTitle: action.bound,
  getLength:computed.struct
});

export default MM2