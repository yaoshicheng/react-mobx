export default {

  namespace: 'app',

  state: {
    name:'这是app的model'
  },

  subscriptions: {

  },

  effects: {

  },

  reducers: {

  },

};
