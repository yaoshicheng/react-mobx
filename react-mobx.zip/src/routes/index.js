import React,{Component} from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import DevTools from 'mobx-react-devtools'
import wifiLogo from '../assets/images/u10.png'
import carPic from '../assets/images/u30.png'
import simPic from '../assets/images/u40.png'
import '../App.css';
import store from "../models/mm"
import MM2 from "../models/mm2";

const mm2 = new MM2("苏D00282D");
store.setTitle("常州1号车");

class App extends Component{
  componentDidMount() {
  }

  naviToCarInfo = ()=>{
    const {dispatch} = this.props;
    dispatch(routerRedux.push(
      {
        pathname: '/carInfo',
      },));
  }

  naviToSimInfo = ()=>{
    const {dispatch} = this.props;
    dispatch(routerRedux.push(
      {
        pathname: '/simInfo',
      },));
  }

  render() {
    return (
      <div className="App">
        {/*<DevTools />*/}
        <div className="indexHeader flex-row">
          <div className="header1">
            <img src={wifiLogo} style={{width:"30px",height:"30px"}} />
          </div>
          <div className="header2">中心服务器 {store.getLength}</div>
          <div className="header3 flex-column">
            <div className="item1">
              <span>车辆名称:</span><span style={{marginLeft:"20px"}}>{store.title}</span>
            </div>
            <div className="item1">
              <span>车牌号码:</span><span style={{marginLeft:"20px"}}>{mm2.name}</span>
            </div>
          </div>
        </div>
        <div className="indexBody">
          <div className="flex-row">
            <div className="item-container">
              <div onClick={this.naviToCarInfo} to="/CarInfoManage" className="manageItem">
                <img src={carPic} style={{width:"18px",height:"39px"}} />
                <div style={{marginLeft:"10px", color:"#333"}}>
                  <div className="itemTitle">车辆信息管理</div>
                  <div>车辆信息管理及录入</div>
                </div>
              </div>
            </div>
            <div className="item-container">
              <div  onClick={this.naviToSimInfo} to="/SimManage" className="manageItem">
                <img src={simPic} style={{width:"41px",height:"32px"}} />
                <div style={{marginLeft:"10px", color:"#333"}}>
                  <div className="itemTitle">SIM卡管理</div>
                  <div>录入SIM卡及流量查询</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default connect()(App)
