import React,{Component} from 'react';
import { observable,autorun } from "mobx";
import { connect } from 'dva'
import { observer } from "mobx-react";
import '../App.css';
import store from "../models/mm"

import MM2 from "../models/mm2";

const mm2 = new MM2("2353");

@connect(({ aaa,loading }) => ({
  aaa,
  loading,
}))
@observer
 class CarInfoManage extends Component{
   constructor(props){
     super(props);
   }

   tmpArray = observable([]);
   @observable tmpArray2 = [];

   aa = autorun(()=>{
     console.log(this.tmpArray.length)
   });

  state={
    deviceModel:"dpsa-12-123",
    deviceCode:"asdadsqdqsdadad123",
    devicePlate:"沪A908X67",
    deviceName:"上海1号车",
    lineName:"AI 71路",
  };
  componentDidMount() {
    store.setTitle("上海1号车上海1号车上海1号车上海1号车");
    let a = observable.map({
      a:1,b:2,c:3
    })
    console.log("has",a.has("a"));
    console.log("keys",a.keys());
    a.set("a",2);
    console.log("get",a.get("a"));
    console.log(store.absoluteVar);
    store.absoluteVar = "1111";
    this.test();
  }
  test=()=>{
    // console.log(store.absoluteVar);
    let b = 0;
    let a = setInterval(()=>{
      if(b<10){
        this.tmpArray.push("1111");
        this.tmpArray2.push("2222");
        b++;
      }
    },2000)
  };

   naviToHome = () =>{
    this.props.history.push("/")
  };

  render(){
    const {deviceModel,deviceCode,devicePlate,deviceName,lineName} = this.state;
    const {aaa:{name}} = this.props;
    return (
        <div className="App">
          {/*<div>*/}
            {/*{this.tmpArray.join('-')}*/}
            {/*<br />*/}
            {/*{this.tmpArray2.join('-')}*/}
          {/*</div>*/}
          <div className="flex-row" style={{width:"90%",marginLeft:"5%",marginTop:"30px"}}>
            <div style={{fontSize:"30px",fontWeight:"bold"}}>车辆信息 ({store.title})</div>
            <div className="navi-home-btn" onClick={this.naviToHome}>返回首页</div>
          </div>
          <div className="indexBody" style={{textAlign:"left",marginTop:"50px"}}>
            <div>
              设备编号：<input/>
            </div>
            <hr style={{margin:"30px 0"}}/>
            <div>
              <div className="carInfoItem">
                <div className="car-info-name">设备型号</div><span>{deviceModel}</span>
              </div>
              <div className="carInfoItem">
                <div className="car-info-name">车牌号</div><span>{devicePlate}</span>
              </div>
              <div className="carInfoItem">
                <div className="car-info-name">车辆名称</div><span>{deviceName}</span>
              </div>
              <div className="carInfoItem">
                <div className="car-info-name">归属线路</div><span>{lineName}</span>
              </div>
            </div>
          </div>
        </div>
    )
  }
}
export default CarInfoManage